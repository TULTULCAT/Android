const express = require('express');
const mysql = require('mysql2');
const app = express();
app.use(express.json());  // ใช้ในการแปลง JSON

// ตั้งค่าการเชื่อมต่อกับฐานข้อมูล MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // ชื่อผู้ใช้ของ MySQL
    password: 'your_password',  // รหัสผ่านของ MySQL
    database: 'houseDB'
});

// เชื่อมต่อกับฐานข้อมูล
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

// POST: บันทึกข้อมูลบ้าน
app.post('/houses', (req, res) => {
    const { area, bedrooms, bathrooms, price, condition, year_built, parking_spots, address, image_url } = req.body;
    const query = `INSERT INTO houses (area, bedrooms, bathrooms, price, condition, year_built, parking_spots, address, image_url) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.query(query, [area, bedrooms, bathrooms, price, condition, year_built, parking_spots, address, image_url], (err, result) => {
        if (err) {
            res.status(500).send('Error saving house data');
        } else {
            res.status(201).send('House data saved successfully');
        }
    });
});

// GET: แสดงข้อมูลบ้านทั้งหมด
app.get('/houses', (req, res) => {
    const query = 'SELECT * FROM houses';
    
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).send('Error retrieving house data');
        } else {
            res.json(results);
        }
    });
});

// ตั้งค่าให้เซิร์ฟเวอร์ทำงานที่พอร์ต 3000
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
